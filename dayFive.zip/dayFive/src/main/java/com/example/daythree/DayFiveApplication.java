package com.example.daythree;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DayFiveApplication {

    public static void main(String[] args) {
        SpringApplication.run(DayFiveApplication.class, args);
    }

}
